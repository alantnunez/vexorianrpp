# Ciudad Roleplay 2D · V4

Todo el proyecto está en **una sola carpeta**. Pixel art, cámara superior y Supabase, igual que la V3.

## Puesta en marcha (5 pasos)

1. **Supabase > SQL Editor > New query**: pega `01_migracion_v4.sql` y pulsa *Run*.
   Es idempotente y no destruye datos: las tablas de la V3 (`players`, `chat`, `dms`, `contacts`, `shots`) pasan a `legacy_*` y quedan cerradas al público.
2. Abre `02_configuracion_manual.sql`, **cambia `TU_CORREO@ejemplo.com` por tu correo real** y ejecútalo.
   Esto reserva el nombre **Alantnunez** y el rol **CREATOR** para ese correo, y guarda el código XTX `3010` como hash bcrypt (solo en el servidor).
3. **Authentication > URL Configuration**: pon la URL donde alojes el juego en *Site URL* y en *Redirect URLs* (necesario para recuperar contraseña y confirmar correos).
4. Sube **todos los archivos menos los dos `.sql`** a tu hosting (Netlify, Vercel, GitHub Pages…). Los `.sql` contienen configuración sensible: no los publiques.
   También funciona en local con un servidor estático (`python3 -m http.server`); abrir `index.html` con doble clic no sirve para la recuperación de contraseña.
5. En el juego: **Crear cuenta** con el mismo correo del paso 2 y la contraseña que tú elijas → se crea como **Alantnunez (CREATOR)**.
   La contraseña nunca se escribe en el código ni en el SQL: la guarda Supabase Auth cifrada.

> Hazlo en este orden y registra tu cuenta cuanto antes. Si no configuras el propietario, nadie puede registrar el nombre Alantnunez.

## Qué incluye

| Sistema | Resumen |
|---|---|
| Mapa 4200×3200 | 5 avenidas y 6 calles, distrito industrial (norte y sur), zona cívica, comercial, 9 barrios residenciales, 2 gasolineras, 6 estacionamientos, parques (lago, jardín botánico, deportivo), terreno en obra reservado para futuras actualizaciones. Se dibuja por teselas de 512 px (≈47 MB en lugar de ≈160 MB). |
| Cuentas | Supabase Auth: iniciar sesión, crear cuenta, recuperar contraseña, cerrar sesión, sesión persistente. Una sola sesión por cuenta (la antigua se cierra). |
| Persistencia | Dinero, inventario, compras, vehículos, propiedades, color de ropa, nivel/XP, vida/hambre/sed/energía, armadura, munición, contactos, mensajes, roles, posición y estado de hospital. Guardado cada 20 s, al ocultar la pestaña y al cerrarla. |
| Movimiento online | Realtime Broadcast + **interpolación por instantáneas** (retardo ≈160 ms), extrapolación corta, animación según distancia recorrida, transición suave al subir/bajar de vehículos. Frecuencia adaptativa 100–250 ms según jugadores (`NETC` en `config.js`). |
| Mensajería | Mensajes privados 1 a 1 con historial, lista de conversaciones, estado en línea, hora, indicador de no leídos, burbujas animadas. Solo remitente y destinatario pueden leerlos (RLS + RPC). No pasan por el chat global. |
| Base XTX | Muros, portón con teclado, iluminación morada, armería, estación de chalecos, almacén, zona de reunión, polígono de tiro con 5 dianas, parqueo. Exige **rol XTX + código** (validado en el servidor, 5 intentos y bloqueo). |
| Hospital | Habitación con 8 camillas, personal NPC. Al morir: camilla, sin poder moverte/conducir, recuperación hasta 100 % calculada con la hora del **servidor** (recargar no sirve), luego «E» para levantarte. |
| Tienda de ropa | Probador con vista previa; color de camiseta y pantalón ($40 por prenda), guardado en la cuenta. |
| Mapa interactivo | Tecla **M**: toda la ciudad, tu posición, zonas y calles, lugares importantes, XTX solo para miembros, otros jugadores, zoom y desplazamiento (ratón, rueda, pellizco). |
| Roles | **XTX** (base, armería, equipo; sin poderes admin) y **CREATOR** (solo Alantnunez). |
| Panel CREATOR | Jugadores (buscar, perfil, roles, expulsar, banear/desbanear), economía (dinero, objetos, compras), mundo (clima, lluvia, tormenta, hora, zonas), historial. Poderes: volar (F6), velocidad (F7), invisibilidad (F8, oculta personaje, nombre y mapa), panel (F9). |
| Audio | Sonido procedural (sin archivos): disparo con variaciones, recarga, puertas, motor, ambiente de ciudad/día/noche/lluvia/tormenta, hospital, objetos, interfaz. Volumen en el menú de pausa. |
| Ajustes | Solo gráficos y rendimiento: calidad Baja/Media/Alta/Ultra, escala de píxeles, FPS, sombras, iluminación, partículas, optimización automática. |
| Rendimiento | 7 autos de tráfico (antes 14) simulados solo cerca del jugador; NPC lejanos sin procesar; colisiones con rejilla espacial. |
| Móvil | Joystick virtual y botones; HUD compacto. |

## Seguridad: qué valida el servidor

Todo lo importante son funciones `SECURITY DEFINER` que leen `auth.uid()`; las tablas no admiten escritura directa desde el navegador.
Dinero y precios (catálogo en la base), compras, pago del trabajo (con tiempo mínimo por entrega), uso de objetos, munición de reserva, armadura, roles, código XTX, equipamiento, baneos (también bloquea el login en Auth), hospital, clima/hora/zonas y todo el panel CREATOR. El rol CREATOR solo puede pertenecer al propietario (trigger + índice único) y no puede asignarse ni retirarse.

## Límites que conviene conocer

- **No hay servidor de juego.** La posición, el daño entre jugadores y los disparos los calcula el navegador de cada jugador (como en la V3). Un cliente modificado podría teletransportarse o volar; lo que no puede es crear dinero, objetos, roles, entrar al portón sin rol/código ni saltarse el hospital. Para autoridad total haría falta un servidor de juego dedicado.
- El cargador (munición cargada) lo lleva el cliente; la reserva y las recargas son del servidor.
- Los mensajes y compras de la V3 no se migran a las cuentas nuevas (no tenían usuario real); siguen en `legacy_*` por si quieres consultarlos.
- La librería `@supabase/supabase-js@2` se carga desde jsDelivr; si prefieres fijar la versión, cambia el `<script>` de `index.html`.
- Con muchos jugadores, sube `sendMin/sendMax` en `config.js` para no saturar el límite de mensajes por segundo de Supabase.

## Archivos

`index.html` · `style.css` + `ui.css` · `config.js` (URL y clave pública) · `settings.js` · `world.js` (datos del mapa y colisiones) · `art.js` (dibujo por teselas) · `interiors.js` · `audio.js` · `api.js` (cuentas y RPC) · `player.js` · `npcs.js` · `vehicles.js` · `net.js` (online, chat, mensajes) · `economy.js` · `combat.js` · `hospital.js` · `clothes.js` · `map.js` · `admin.js` · `phone.js` · `game.js` · `ui.js` · `01_migracion_v4.sql` · `02_configuracion_manual.sql`

## Controles

WASD mover · Shift correr · E interactuar · F vehículo · G sacar arma · R recargar · clic disparar · 1-9 objetos · M mapa · P teléfono · Enter chat · Esc menú · F3 FPS.
