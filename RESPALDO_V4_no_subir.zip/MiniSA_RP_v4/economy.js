// MiniSA RP · V4 · economía. Dinero, inventario, compras y pagos los valida el servidor (RPC); aquí solo se muestran.
const job={active:false,order:null,boxes:0,earned:0};
const money=n=>"$"+Math.round(n).toLocaleString("es");
const catItem=k=>(ME.catalog.items||[]).find(i=>i.item_key===k);

function syncInvFlags(){
  player.hasPhone=!!player.inv.phone;player.weapon=!!player.inv.pistol;player.reserve=player.inv.ammo||0;
  if(!player.weapon)player.armed=false;
  refreshHotbar();
}
function useSlots(){return (ME.catalog.items||[]).filter(i=>["food","drink","med"].includes(i.kind)&&(player.inv[i.item_key]||0)>0).slice(0,9)}
function refreshHotbar(){
  const bar=document.getElementById("hotbar");if(!bar)return;bar.innerHTML="";
  useSlots().forEach((it,i)=>{
    const b=document.createElement("button");b.className="slot";b.title=it.name;
    b.innerHTML=`<small>${i+1}</small>${it.icon}<b>${player.inv[it.item_key]}</b>`;
    b.onclick=()=>useItem(it.item_key);bar.appendChild(b);
  });
  const w=document.getElementById("weapon");
  if(w){if(player.weapon){w.style.display="block";w.textContent=(player.armed?"🔫 ":"🔫 (G) ")+player.ammo+" / "+player.reserve+(player.armor>0?"  🦺 "+Math.round(player.armor):"")}else if(player.armor>0){w.style.display="block";w.textContent="🦺 "+Math.round(player.armor)}else w.style.display="none"}
}
async function useItem(key){
  if(!canControl())return;
  try{
    const r=await rpc("use_item",{p_key:key});
    player.hunger=Math.min(100,player.hunger+r.hunger);player.thirst=Math.min(100,player.thirst+r.thirst);
    player.energy=Math.min(100,player.energy+r.energy);player.hp=Math.min(100,player.hp+r.hp);
    player.inv[key]=r.qty;if(!r.qty)delete player.inv[key];syncInvFlags();sfxPickup();
    const it=catItem(key);floatText(player.x,player.y-28,it?it.icon:"✔","#b5ed67");
  }catch(e){toast(e.message);sfxError()}
}
async function reloadGun(){
  if(!player.weapon||player.ammo>=12)return;
  try{const r=await rpc("reload_gun");player.ammo=r.loaded;player.reserve=r.reserve;player.inv.ammo=r.reserve;sfxReload();refreshHotbar();
    if(r.loaded===0)toast("Sin munición. Pide más en la armería XTX.")}catch(e){toast(e.message)}
}

// ---------- Trabajo del almacén ----------
function updateMission(){
  const t=document.getElementById("m-title"),x=document.getElementById("m-text"),m=document.getElementById("mission");if(!t)return;
  if(!job.active){t.textContent="Empleo en el almacén";x.textContent="Habla con Marco para empezar tu turno. Cada entrega sube tu nivel.";m.classList.remove("hide");return}
  if(!job.order){t.textContent="Turno activo";x.textContent="Esperando pedido…"}
  else if(!player.carry){t.textContent="Pedido: caja del estante "+job.order.shelf;x.textContent="Recoge la caja del estante "+job.order.shelf+" (E) y llévala al muelle de carga."}
  else{t.textContent="Entrega la caja";x.textContent="Llévala al muelle de carga (E) para cobrar. ¡Rápido paga más!"}
  m.classList.remove("hide");
}
async function startShift(){
  try{await rpc("job_start_shift");job.active=true;job.boxes=0;job.earned=0;await newOrder();toast("Marco: ¡Turno iniciado! Mueve esas cajas.")}catch(e){toast(e.message)}
}
async function newOrder(){
  const s=INTERIOR.shelves[Math.random()*INTERIOR.shelves.length|0];
  try{await rpc("job_new_order");job.order={shelf:s.id,t:Date.now()};updateMission()}catch(e){toast(e.message)}
}
async function endShift(){
  try{const r=await rpc("job_end_shift");player.money=r.money;job.active=false;job.order=null;player.carry=false;updateMission();
    toast(`Turno terminado · ${r.boxes} cajas · ganaste ${money(r.earned)}${r.bonus?" (bono "+money(r.bonus)+")":""}`)}catch(e){toast(e.message)}
}
async function deliverBox(){
  try{
    const r=await rpc("job_deliver");player.carry=false;player.money=r.money;ME.level=r.level;job.boxes++;job.earned+=r.pay;
    sfxBuy();floatText(player.x,player.y-30,"+"+money(r.pay),"#b5ed67");
    toast(`Entrega correcta: +${money(r.pay)}${r.notes&&r.notes.length?" ("+r.notes.join(", ")+")":""} · Nivel ${r.level}`);
    await newOrder();
  }catch(e){toast(e.message);sfxError();if(/pedido/i.test(e.message)){player.carry=false;await newOrder()}}
}
function pickBox(){player.carry=true;sfxPickup();toast("Caja recogida. Llévala al muelle.");updateMission()}

// ---------- Panel genérico ----------
function openPanel(title,sub,build){
  if(PH.open)togglePhone();const o=document.getElementById("panel");document.getElementById("panel-title").textContent=title;document.getElementById("panel-sub").textContent=sub||"";
  const box=document.getElementById("panel-body");box.innerHTML="";build(box);o.style.display="grid";paused=true;panelOpen=true;
}
function closePanel(){document.getElementById("panel").style.display="none";panelOpen=false;paused=false;if(typeof onPanelClose==="function")onPanelClose();onPanelClose=null}
let panelOpen=false,onPanelClose=null;
function rowEl(icon,name,sub,btnText,fn,disabled){
  const r=document.createElement("div");r.className="shop-row";
  r.innerHTML=`<i>${icon}</i><div class="grow"><b></b><small></small></div>`;
  r.querySelector("b").textContent=name;r.querySelector("small").textContent=sub||"";
  if(btnText){const b=document.createElement("button");b.textContent=btnText;b.disabled=!!disabled;b.onclick=()=>fn(b);r.appendChild(b)}
  return r;
}
function moneyEl(){const d=document.createElement("div");d.className="shop-money";d.id="panel-money";d.textContent="Tu dinero: "+money(player.money);return d}
function setPanelMoney(){const e=document.getElementById("panel-money");if(e)e.textContent="Tu dinero: "+money(player.money)}
function effectText(i){const p=[];if(i.hunger)p.push((i.hunger>0?"+":"")+i.hunger+" comida");if(i.thirst)p.push((i.thirst>0?"+":"")+i.thirst+" sed");if(i.hp)p.push("+"+i.hp+" vida");if(i.energy)p.push("+"+i.energy+" energía");return p.join(" · ")||(i.kind==="tech"?"Permite usar el teléfono":"")}
function zoneOpen(z){return ME.creator||ME.world.zones[z]!==false}

function openShop(){
  if(!zoneOpen("supermercado")){toast("El supermercado está cerrado por la administración.");return}
  openPanel("Supermercado 24/7","Rosa te atiende",box=>{
    box.appendChild(moneyEl());
    (ME.catalog.items||[]).filter(i=>i.buyable).forEach(it=>{
      const have=player.inv[it.item_key]||0;
      box.appendChild(rowEl(it.icon,it.name,effectText(it)+(have?` · tienes ${have}`:""),money(it.price),async b=>{
        b.disabled=true;
        try{const r=await rpc("buy_item",{p_key:it.item_key,p_qty:1});player.money=r.money;player.inv[it.item_key]=r.qty;syncInvFlags();sfxBuy();setPanelMoney();
          b.parentNode.querySelector("small").textContent=effectText(it)+` · tienes ${r.qty}`;if(it.unique_item)b.textContent="Ya lo tienes";else b.disabled=false}
        catch(e){toast(e.message);sfxError();b.disabled=false}
      },it.unique_item&&have>0));
    });
  });
}
function openDealer(){
  if(!zoneOpen("concesionario")){toast("El concesionario está cerrado.");return}
  openPanel("Concesionario","Iván: todos los autos incluyen tanque lleno",box=>{
    box.appendChild(moneyEl());
    const mine=cars.filter(c=>c.owned).length;
    (ME.catalog.vehicles||[]).forEach(v=>{
      box.appendChild(rowEl("🚗",v.name,"Velocidad "+Math.round(v.speed*100)+"% · se guarda en tu cuenta",money(v.price),async b=>{
        b.disabled=true;
        try{const r=await rpc("buy_vehicle",{p_key:v.veh_key});player.money=r.money;ME.vehicles.push({id:r.id,model:r.model,color:r.color,plate:r.plate});
          addOwnedCar({id:r.id,model:r.model,color:r.color,plate:r.plate},ME.vehicles.length-1);sfxBuy();setPanelMoney();toast("¡Comprado! Tu "+v.name+" te espera frente al concesionario.");closePanel()}
        catch(e){toast(e.message);sfxError();b.disabled=false}
      }));
    });
    const n=document.createElement("small");n.className="muted";n.textContent=`Tienes ${mine} de 4 vehículos posibles. Pulsa F cerca de ellos para conducir.`;box.appendChild(n);
  });
}
function propState(b){return ME.properties.find(p=>p.key===b.sale)}
function openProperty(b){
  const cat=(ME.catalog.properties||[]).find(p=>p.property_key===b.sale),st=propState(b);
  if(!cat)return;
  if(st){toast(st.mine?"Esta es tu casa. ¡Bienvenido!":"Casa de "+st.owner+".");return}
  openPanel(cat.name,"Propiedad en venta",box=>{
    box.appendChild(moneyEl());
    box.appendChild(rowEl("🏠",cat.name,"Barrio "+b.district+" · queda registrada a tu nombre",money(cat.price),async btn=>{
      btn.disabled=true;
      try{const r=await rpc("buy_property",{p_key:b.sale});player.money=r.money;ME.properties.push({key:b.sale,owner:ME.username,mine:true});sfxBuy();toast("¡Ahora eres propietario de "+cat.name+"!");closePanel()}
      catch(e){toast(e.message);sfxError();btn.disabled=false}
    }));
  });
}

// ---------- XTX: portón, armería y chalecos (el servidor valida rol + código) ----------
function xtxNearGate(){return Math.hypot(player.x-(XTX.gate.x+XTX.gate.w/2),player.y-(XTX.gate.y+8))<110}
function openKeypad(){
  openPanel("Portón XTX","Zona privada · requiere rol XTX y código",box=>{
    const inp=document.createElement("input");inp.type="password";inp.maxLength=12;inp.placeholder="Código de acceso";inp.autocomplete="off";inp.inputMode="numeric";
    const msg=document.createElement("div");msg.className="pass-msg";
    const go=document.createElement("button");go.textContent="Entrar";
    const run=async()=>{
      go.disabled=true;msg.textContent="";
      try{const r=await rpc("xtx_enter",{p_code:inp.value});
        if(r.ok){ME.xtxAccess=true;sfxDoor(true);toast("Acceso concedido. Bienvenido a la base.");closePanel()}
        else{msg.textContent=r.msg||"Acceso denegado.";sfxError()}}
      catch(e){msg.textContent=e.message}
      go.disabled=false;inp.value="";
    };
    go.onclick=run;inp.addEventListener("keydown",e=>{if(e.key==="Enter")run();e.stopPropagation()});
    box.append(inp,msg,go);setTimeout(()=>inp.focus(),50);
  });
}
async function xtxClaim(kind,btn){
  if(btn)btn.disabled=true;
  try{
    const r=await rpc("xtx_claim",{p_kind:kind});
    player.inv=r.inv;if(r.equipment){player.ammo=r.equipment.ammo_loaded}syncInvFlags();sfxPickup();toast(r.msg);
  }catch(e){toast(e.message);sfxError()}
  if(btn)btn.disabled=false;
}
function openArmory(){
  openPanel("Armería XTX","Solo miembros autorizados",box=>{
    box.appendChild(rowEl("🔫","Pistola","Una por miembro. Incluye 24 balas de reserva.","Recoger",b=>xtxClaim("pistol",b)));
    box.appendChild(rowEl("🔸","Munición","+24 balas (máx. 120 en reserva)","Recoger",b=>xtxClaim("ammo",b)));
    box.appendChild(rowEl("🎒","Equipo XTX","Equipo de la banda","Recoger",b=>xtxClaim("kit",b)));
  });
}
function openVests(){
  openPanel("Estación de chalecos","Chalecos antibalas XTX",box=>{
    box.appendChild(rowEl("🦺","Recoger chaleco","Un chaleco por miembro","Recoger",b=>xtxClaim("vest",b)));
    box.appendChild(rowEl("🛡️","Equipar chaleco","Te da 100 puntos de armadura","Equipar",async b=>{
      b.disabled=true;
      try{const r=await rpc("equip_vest");player.armor=r.armor;player.inv=r.inv;syncInvFlags();sfxPickup();toast("Chaleco equipado: armadura al 100%.")}
      catch(e){toast(e.message);sfxError()}b.disabled=false;
    }));
  });
}
